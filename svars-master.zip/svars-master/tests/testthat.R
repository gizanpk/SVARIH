library(testthat)
library(svars)

test_check("svars")
