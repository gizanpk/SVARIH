#' @S3method print svarfevd

print.svarfevd <- function(x, ...){

  cat("\nForecast error decomposition:\n")
  print(x[])
  invisible(x)
}
