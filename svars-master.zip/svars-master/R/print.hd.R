#' @S3method print hd

print.hd <- function(x, ...){

  cat("\nHistorical decomposition:\n")
  print(x[])
  invisible(x)
}
